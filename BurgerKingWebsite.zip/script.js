function MoveBars(x) {
  x.classList.toggle("change");
}

function ImgGrid() {
    location.href = 'https://www.google.co.uk';
}

function BottomBar() {
    location.href = 'https://www.google.co.uk';
}